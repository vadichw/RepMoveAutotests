export const users = {
    standard: { login: "repmv11@mailinator.com"},
};